package exception;

public class testException {
}
