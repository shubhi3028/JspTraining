package model.response;

public class CreateUserResponse {
}
